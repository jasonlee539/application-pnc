
require "upb"
return require "upb.pb_c"
