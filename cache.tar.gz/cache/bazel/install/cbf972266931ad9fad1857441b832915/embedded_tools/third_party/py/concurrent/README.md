[concurrent](https://github.com/agronholm/pythonfutures)
--------

Backport of the concurrent.futures package from Python 3.2, version 2.1.2

* Version: 2.1.2
* License: BSD License
* From: [http://pypi.python.org/packages/source/f/futures/futures-2.1.2.tar.gz](http://pypi.python.org/packages/source/f/futures/futures-2.1.2.tar.gz)
