#include "examples/test_cc_shared_library/qux2.h"

int qux2() { return 42; }
